
function onStart () {
	sf.scene.show('SceneBrowser');
	sf.scene.focus('SceneBrowser');
}
function onDestroy () {
	//stop your XHR or Ajax operation and put codes to destroy your application here
	
}

alert("init.js loaded.");
