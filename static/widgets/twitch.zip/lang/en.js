alert("English (en) loaded");
var STR_CHANNELS = "Channels";
var STR_GAMES = "Games";
var STR_OPEN = "Open";
var STR_REFRESH = "Refresh";

var STR_PLACEHOLDER_OPEN = "Enter channel name...";

var STR_QUALITY = "Quality";

var STR_RETRYING = "Retrying";
var STR_VIEWER = "Viewers";
var STR_BUFFERING = "Buffering";


var STR_ERROR_RENDER_SOURCE = "Format not supported :(";
var STR_ERROR_RENDER_FIXED = "Sorry but it seems like stream\nqualities High/Medium/Low are not supported\non your TV. Try Source quality on various streams.";
var STR_ERROR_NETWORK_DISCONNECT= "Network disconnected.";
var STR_ERROR_STREAM_NOT_FOUND = "Stream not found.";
var STR_ERROR_AUTHENTICATION_FAIL = "Authentication failed.";
var STR_ERROR_CONNECTION_FAIL = "Connection failed.";