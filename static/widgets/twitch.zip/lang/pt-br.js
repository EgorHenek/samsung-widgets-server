alert("Português (pt-br) carregado");
var STR_CHANNELS = "Canais";
var STR_GAMES = "Jogos";
var STR_OPEN = "Abrir";
var STR_REFRESH = "Atualizar";

var STR_PLACEHOLDER_OPEN = "Insira o nome do canal";

var STR_QUALITY = "Qualidade";

var STR_RETRYING = "Tentando novamente";
var STR_VIEWER = "Viewers";
var STR_BUFFERING = "Buffering";


var STR_ERROR_RENDER_SOURCE = "Formato não suportado :(";
var STR_ERROR_RENDER_FIXED = "Desculpe mas parece que as qualidades\n High/Medium/Low não são suportadas\npela sua TV. Tente a qualidade Source.";
var STR_ERROR_NETWORK_DISCONNECT= "Rede desconectada.";
var STR_ERROR_STREAM_NOT_FOUND = "Stream não encontrada.";
var STR_ERROR_AUTHENTICATION_FAIL = "Falha na autenticação.";
var STR_ERROR_CONNECTION_FAIL = "Falha na conexão.";
