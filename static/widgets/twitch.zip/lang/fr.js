alert("French (fr) loaded");
var STR_CHANNELS = "Chaînes";
var STR_GAMES = "Jeux";
var STR_OPEN = "Ouvrir";
var STR_REFRESH = "Rafraîchir";

var STR_PLACEHOLDER_OPEN = "Entrer le nom de la chaîne...";

var STR_QUALITY = "Qualité";

var STR_RETRYING = "Nouvelle tentative";
var STR_VIEWER = "Spectateurs";
var STR_BUFFERING = "Mise en mémoire tampon";


var STR_ERROR_RENDER_SOURCE = "Format non supporté :(";
var STR_ERROR_RENDER_FIXED = "Désolé mais il semble que les qualités de\nvidéo Haute/Moyenne/Basse ne sont pas supportées\nsur votre TV. Essayez la qualité Source sur divers diffusions.";
var STR_ERROR_NETWORK_DISCONNECT= "Connexion réseau deconnectée.";
var STR_ERROR_STREAM_NOT_FOUND = "Diffusion introuvable.";
var STR_ERROR_AUTHENTICATION_FAIL = "Authentification échouée.";
var STR_ERROR_CONNECTION_FAIL = "Connexion échouée.";
