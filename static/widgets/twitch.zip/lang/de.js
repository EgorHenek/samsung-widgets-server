alert("German (de) loaded");
var STR_CHANNELS = "Kanäle";
var STR_GAMES = "Spiele";
var STR_OPEN = "Kanal öffnen";
var STR_REFRESH = "Neu laden";

var STR_PLACEHOLDER_OPEN = "Kanalnamen eingeben...";

var STR_QUALITY = "Qualität";

var STR_RETRYING = "Versuch"; 
var STR_VIEWER = "Zuschauer";
var STR_BUFFERING = "Puffer";


var STR_ERROR_RENDER_SOURCE = "Format not supported :(";
var STR_ERROR_RENDER_FIXED = "Sorry but it seems like stream\nqualities High/Medium/Low are not supported\non your TV. Try Source quality on various streams.";
var STR_ERROR_NETWORK_DISCONNECT= "Netzwerk nicht erreichbar.";
var STR_ERROR_STREAM_NOT_FOUND = "Stream nicht gefunden.";
var STR_ERROR_AUTHENTICATION_FAIL = "Authentifizierung fehlgeschlagen.";
var STR_ERROR_CONNECTION_FAIL = "Verbindungsaufbau fehlgeschlagen.";